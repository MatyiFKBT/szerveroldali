<?php
class Valami {

}
