const { Service } = require('feathers-sequelize');

exports.Tracks = class Tracks extends Service {
  
};
