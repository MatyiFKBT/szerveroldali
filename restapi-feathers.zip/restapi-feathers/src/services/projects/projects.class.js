const { Service } = require('feathers-sequelize');

exports.Projects = class Projects extends Service {
  
};
