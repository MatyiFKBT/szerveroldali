const { add, multiply } = require('./math.js')
const math = require('./math.js')
console.log(add(40, 2))
console.log(multiply(40, 2))