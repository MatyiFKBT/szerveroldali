const a = 12;
console.log(a);