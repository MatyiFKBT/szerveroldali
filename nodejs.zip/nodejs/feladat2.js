const faker = require('faker');

const randomName = faker.name.findName(); // Rowan Nikolaus

console.log(randomName)